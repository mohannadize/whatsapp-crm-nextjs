import { Contacts } from '@/app/_components/contacts';

export default function ContactsPage() {
  return (
    <main>
      <Contacts />
    </main>
  );
}
