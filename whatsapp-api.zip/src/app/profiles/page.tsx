import { Profiles } from '@/app/_components/profiles';

export default function ProfilesPage() {
  return (
    <main>
      <Profiles />
    </main>
  );
}
